# ESP8266-Eagle_Library
Eagle library for the ESP8266

Credits go to Skutch; acquired from http://www.esp8266.com/viewtopic.php?p=8868

Olimex MOD-WIFI-ESP8266-DEV board by https://github.com/rene79
